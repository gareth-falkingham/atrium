#ifndef __GETS__H_
#define __GETS__H_

#ifdef __cplusplus
extern "C" {
#endif

char * Gets ( char * str, int num );

#ifdef __cplusplus
}
#endif

#endif
