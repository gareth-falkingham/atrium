#include "EmptyHeader.h"

#ifdef RAKNET_SOCKET_2_INLINE_FUNCTIONS

#ifndef RAKNETSOCKET2_PS3_PS4_CPP
#define RAKNETSOCKET2_PS3_PS4_CPP














#endif // file header

#endif // #ifdef RAKNET_SOCKET_2_INLINE_FUNCTIONS
